class HomesController < ApplicationController
  def home
  end
end
